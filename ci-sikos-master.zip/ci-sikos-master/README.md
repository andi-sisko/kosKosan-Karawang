## Membangun Aplikasi Kosan Menggunakan Framework Codeigniter

Berikut adalah beberapa screenshoot fitur yang ada dalam aplikasi ini:
![8](https://user-images.githubusercontent.com/13019337/50308830-03ccb700-04cf-11e9-996e-0c74a2b078d1.png)
![10](https://user-images.githubusercontent.com/13019337/50308733-c10adf00-04ce-11e9-8ff6-83a5a3af6398.png)
![9](https://user-images.githubusercontent.com/13019337/50308735-c36d3900-04ce-11e9-8b61-0e36df819fcf.png)
![11](https://user-images.githubusercontent.com/13019337/50308768-daac2680-04ce-11e9-9d20-a1506e71157a.png)
![12](https://user-images.githubusercontent.com/13019337/50308781-e39cf800-04ce-11e9-910b-9bee79bdda5c.png)
![13](https://user-images.githubusercontent.com/13019337/50308788-e861ac00-04ce-11e9-9fec-48c5a79b59b2.png)





