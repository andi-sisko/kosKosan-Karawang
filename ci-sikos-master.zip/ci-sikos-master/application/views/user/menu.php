            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="header">MENU KOS</li>
                    <li class="active">
                        <a href="<?php echo base_url()?>Main_Front_User/index">
                            <i class="material-icons">home</i>
                            <span>Semua Kos</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url()?>Main_Front_User/kos_putra">
                            <i class="material-icons">home</i>
                            <span>Kos Putra</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url()?>Main_Front_User/kos_putri">
                            <i class="material-icons">home</i>
                            <span>Kos Putri</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url()?>Main_Front_User/kos_campur">
                            <i class="material-icons">home</i>
                            <span>Kos Campur</span>
                        </a>
                    </li>
                    <li class="header"></li>
                    <li>
                        <a href="<?php echo base_url()?>Main_Back_User/daftar_user">
                            <i class="material-icons">input</i>
                            <span>Daftar</span>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- #Menu -->